package com.code.zila.maishainfotechTask;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    EditText email,pass,name,address,mobile;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main2 );

        email=findViewById(R.id.emai );
        pass=findViewById(R.id.pass );
        name=findViewById(R.id.name );
        address=findViewById(R.id.address );
        mobile=findViewById(R.id.mobile );
        btn=findViewById( R.id.btnlgn );

        btn.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String useremail = email.getText().toString();
                String userpassword = pass.getText().toString();
                String username = name.getText().toString();
                String useraddress = address.getText().toString();
                String usermobile = mobile.getText().toString();
                if (useremail.isEmpty()) {
                    email.requestFocus();
                    email.setError( "please enter your Email " );
                    return;
                }
                else if (!Patterns.EMAIL_ADDRESS.matcher( useremail ).matches()) {
                    email.requestFocus();
                    email.setError( "please enter correct email" );
                    return;
                }
                else if (userpassword.isEmpty()) {
                    pass.requestFocus();
                    pass.setError( "please enter your password" );
                    return;
                }
                if (username.isEmpty()) {
                    name.requestFocus();
                    name.setError( "please enter your Name " );
                    return;
                }
                else if (useraddress.isEmpty()) {
                    address.requestFocus();
                    address.setError( "please enter your Address" );
                    return;
                }
                else if (usermobile.isEmpty()) {
                    mobile.requestFocus();
                    mobile.setError( "please enter your Mobile" );
                    return;
                }
                else
                {
                    loginUser( );
                }


            }
        } );

    }

    private void loginUser()
    {
        Toast.makeText( this, "Validation Done ", Toast.LENGTH_SHORT ).show();
        
    }

    public void call(View view) {
        Intent intent= new Intent(getApplicationContext(),MainActivity.class);
        startActivity(intent);
    }
}