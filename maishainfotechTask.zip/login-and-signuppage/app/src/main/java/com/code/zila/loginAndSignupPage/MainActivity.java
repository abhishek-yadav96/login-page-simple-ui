package com.code.zila.maishainfotechTask;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;

public class MainActivity extends AppCompatActivity {

    EditText email,password;
    Button btn;
    androidx.appcompat.widget.AppCompatButton signInButton;
    GoogleSignInClient mGoogleSignInClient;
    private static int RC_SIGN_IN= 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main);
        signInButton=findViewById(R.id.signInButton);


        email=findViewById(R.id.emailField1 );
        password=findViewById(R.id.passfield );
        btn=findViewById( R.id.btn );


        signInButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(getApplicationContext(),SecondActivity.class);
                startActivity(intent);
            }

        });

        btn.setOnClickListener( view -> {
            String useremail = email.getText().toString();
            String userpassword = password.getText().toString();
            if (useremail.isEmpty()) {
                email.requestFocus();
                email.setError("please enter your Email ");
                return;
            } else if (!Patterns.EMAIL_ADDRESS.matcher(useremail).matches()) {
                email.requestFocus();
                email.setError("please enter correct email");
                return;
            } else if (userpassword.isEmpty()) {
                password.requestFocus();
                password.setError("please enter your password");
                return;
            } else {
                loginUser();
            }

               });
    }
                @Override
                public void onActivityResult(int requestCode, int resultCode, Intent data) {
                    super.onActivityResult(requestCode, resultCode, data);

                    if (requestCode == RC_SIGN_IN) {
                        Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
                        handleSignInResult(task);
                    }
                }
                private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
                    try {
                        GoogleSignInAccount account = completedTask.getResult(ApiException.class);

                        GoogleSignInAccount acct = GoogleSignIn.getLastSignedInAccount(this);
                        if (acct != null) {
                            String personName = acct.getDisplayName();
                            String personGivenName = acct.getGivenName();
                            String personFamilyName = acct.getFamilyName();
                            String personEmail = acct.getEmail();
                            String personId = acct.getId();
                            Uri personPhoto = acct.getPhotoUrl();

                            Toast.makeText(this,"User email : "+personEmail,Toast.LENGTH_SHORT).show();
                        }
                        //startActivity(new Intent(MainActivity.this , SecondActivity.class));

                        // Signed in successfully, show authenticated UI.

                    }
                    catch (ApiException e) {

                        Log.d("Message", e.toString());
                    }
                }

    private void loginUser() {
        Toast.makeText( this, "Validation Done", Toast.LENGTH_SHORT ).show();
    }

    public void signup(View view) {

        Intent intent= new Intent(getApplicationContext(),MainActivity2.class);
        startActivity(intent);
    }

}
